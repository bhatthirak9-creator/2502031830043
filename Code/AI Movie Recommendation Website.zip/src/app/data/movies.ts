export interface Movie {
  id: number;
  title: string;
  rating: number;
  genre: string;
  year: number;
  description: string;
  image: string;
  mood?: string;
  language?: string;
  director?: string;
  duration?: string;
}

export const movies: Movie[] = [
  {
    id: 1,
    title: "Inception",
    rating: 4.8,
    genre: "Action",
    year: 2010,
    description: "A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.",
    image: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800&q=80",
    mood: "Thriller",
    language: "English",
    director: "Christopher Nolan",
    duration: "2h 28m"
  },
  {
    id: 2,
    title: "The Dark Knight",
    rating: 4.9,
    genre: "Action",
    year: 2008,
    description: "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests.",
    image: "https://images.unsplash.com/photo-1509347528160-9a9e33742cdb?w=800&q=80",
    mood: "Thriller",
    language: "English",
    director: "Christopher Nolan",
    duration: "2h 32m"
  },
  {
    id: 3,
    title: "Interstellar",
    rating: 4.7,
    genre: "Sci-Fi",
    year: 2014,
    description: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.",
    image: "https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?w=800&q=80",
    mood: "Thriller",
    language: "English",
    director: "Christopher Nolan",
    duration: "2h 49m"
  },
  {
    id: 4,
    title: "The Notebook",
    rating: 4.5,
    genre: "Romance",
    year: 2004,
    description: "A poor yet passionate young man falls in love with a rich young woman, giving her a sense of freedom, but they are soon separated.",
    image: "https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?w=800&q=80",
    mood: "Romantic",
    language: "English",
    director: "Nick Cassavetes",
    duration: "2h 3m"
  },
  {
    id: 5,
    title: "La La Land",
    rating: 4.6,
    genre: "Romance",
    year: 2016,
    description: "While navigating their careers in Los Angeles, a pianist and an actress fall in love while attempting to reconcile their aspirations for the future.",
    image: "https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?w=800&q=80",
    mood: "Romantic",
    language: "English",
    director: "Damien Chazelle",
    duration: "2h 8m"
  },
  {
    id: 6,
    title: "The Shawshank Redemption",
    rating: 5.0,
    genre: "Drama",
    year: 1994,
    description: "Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.",
    image: "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=800&q=80",
    mood: "Happy",
    language: "English",
    director: "Frank Darabont",
    duration: "2h 22m"
  },
  {
    id: 7,
    title: "Pulp Fiction",
    rating: 4.8,
    genre: "Crime",
    year: 1994,
    description: "The lives of two mob hitmen, a boxer, a gangster and his wife intertwine in four tales of violence and redemption.",
    image: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=800&q=80",
    mood: "Thriller",
    language: "English",
    director: "Quentin Tarantino",
    duration: "2h 34m"
  },
  {
    id: 8,
    title: "Forrest Gump",
    rating: 4.7,
    genre: "Drama",
    year: 1994,
    description: "The presidencies of Kennedy and Johnson unfold through the perspective of an Alabama man with an IQ of 75.",
    image: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800&q=80",
    mood: "Happy",
    language: "English",
    director: "Robert Zemeckis",
    duration: "2h 22m"
  },
  {
    id: 9,
    title: "The Matrix",
    rating: 4.8,
    genre: "Action",
    year: 1999,
    description: "A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers.",
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80",
    mood: "Action",
    language: "English",
    director: "The Wachowskis",
    duration: "2h 16m"
  },
  {
    id: 10,
    title: "Fight Club",
    rating: 4.7,
    genre: "Thriller",
    year: 1999,
    description: "An insomniac office worker and a devil-may-care soap maker form an underground fight club that evolves into much more.",
    image: "https://images.unsplash.com/photo-1533613220915-609f661a6fe1?w=800&q=80",
    mood: "Thriller",
    language: "English",
    director: "David Fincher",
    duration: "2h 19m"
  },
  {
    id: 11,
    title: "Goodfellas",
    rating: 4.8,
    genre: "Crime",
    year: 1990,
    description: "The story of Henry Hill and his life in the mob, covering his relationship with his wife and his partners in crime.",
    image: "https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=800&q=80",
    mood: "Thriller",
    language: "English",
    director: "Martin Scorsese",
    duration: "2h 26m"
  },
  {
    id: 12,
    title: "Titanic",
    rating: 4.6,
    genre: "Romance",
    year: 1997,
    description: "A seventeen-year-old aristocrat falls in love with a kind but poor artist aboard the luxurious, ill-fated R.M.S. Titanic.",
    image: "https://images.unsplash.com/photo-1464037866556-6812c9d1c72e?w=800&q=80",
    mood: "Romantic",
    language: "English",
    director: "James Cameron",
    duration: "3h 14m"
  },
  {
    id: 13,
    title: "Gladiator",
    rating: 4.7,
    genre: "Action",
    year: 2000,
    description: "A former Roman General sets out to exact vengeance against the corrupt emperor who murdered his family and sent him into slavery.",
    image: "https://images.unsplash.com/photo-1594908900066-3f47337549d8?w=800&q=80",
    mood: "Action",
    language: "English",
    director: "Ridley Scott",
    duration: "2h 35m"
  },
  {
    id: 14,
    title: "The Departed",
    rating: 4.7,
    genre: "Crime",
    year: 2006,
    description: "An undercover cop and a mole in the police attempt to identify each other while infiltrating an Irish gang in Boston.",
    image: "https://images.unsplash.com/photo-1574267432644-f610f5b9ce40?w=800&q=80",
    mood: "Thriller",
    language: "English",
    director: "Martin Scorsese",
    duration: "2h 31m"
  },
  {
    id: 15,
    title: "The Prestige",
    rating: 4.6,
    genre: "Drama",
    year: 2006,
    description: "After a tragic accident, two stage magicians engage in a battle to create the ultimate illusion while sacrificing everything.",
    image: "https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?w=800&q=80",
    mood: "Thriller",
    language: "English",
    director: "Christopher Nolan",
    duration: "2h 10m"
  },
  {
    id: 16,
    title: "Coco",
    rating: 4.8,
    genre: "Animation",
    year: 2017,
    description: "Aspiring musician Miguel confronts his family's ancestral ban on music and enters the Land of the Dead to find his great-great-grandfather.",
    image: "https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?w=800&q=80",
    mood: "Happy",
    language: "English",
    director: "Lee Unkrich",
    duration: "1h 45m"
  },
  {
    id: 17,
    title: "Joker",
    rating: 4.5,
    genre: "Drama",
    year: 2019,
    description: "In Gotham City, mentally troubled comedian Arthur Fleck is disregarded and mistreated by society, leading to a downward spiral.",
    image: "https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=800&q=80",
    mood: "Thriller",
    language: "English",
    director: "Todd Phillips",
    duration: "2h 2m"
  },
  {
    id: 18,
    title: "Parasite",
    rating: 4.9,
    genre: "Thriller",
    year: 2019,
    description: "Greed and class discrimination threaten the newly formed symbiotic relationship between the wealthy Park family and the destitute Kim clan.",
    image: "https://images.unsplash.com/photo-1524712245354-2c4e5e7121c0?w=800&q=80",
    mood: "Thriller",
    language: "Korean",
    director: "Bong Joon-ho",
    duration: "2h 12m"
  }
];

export const trendingMovies = movies.slice(0, 6);
export const actionMovies = movies.filter(m => m.genre === "Action");
export const romanceMovies = movies.filter(m => m.genre === "Romance");
export const dramaMovies = movies.filter(m => m.genre === "Drama");
