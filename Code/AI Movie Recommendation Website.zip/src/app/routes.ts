import { createBrowserRouter } from 'react-router';
import LandingPage from './pages/LandingPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import Dashboard from './pages/Dashboard';
import MovieDetail from './pages/MovieDetail';
import AIRecommendation from './pages/AIRecommendation';
import Genres from './pages/Genres';
import Watchlist from './pages/Watchlist';
import Profile from './pages/Profile';
import Contact from './pages/Contact';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: LandingPage,
  },
  {
    path: '/login',
    Component: LoginPage,
  },
  {
    path: '/register',
    Component: RegisterPage,
  },
  {
    path: '/dashboard',
    Component: Dashboard,
  },
  {
    path: '/movie/:id',
    Component: MovieDetail,
  },
  {
    path: '/ai-recommendation',
    Component: AIRecommendation,
  },
  {
    path: '/genres',
    Component: Genres,
  },
  {
    path: '/watchlist',
    Component: Watchlist,
  },
  {
    path: '/profile',
    Component: Profile,
  },
  {
    path: '/contact',
    Component: Contact,
  },
]);
