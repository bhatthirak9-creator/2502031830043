import { useState } from 'react';
import { Bookmark } from 'lucide-react';
import { Navbar } from '../components/Navbar';
import { Sidebar } from '../components/Sidebar';
import { MobileNav } from '../components/MobileNav';
import { MobileMenu } from '../components/MobileMenu';
import { MovieCard } from '../components/MovieCard';
import { movies, Movie } from '../data/movies';

export default function Watchlist() {
  // Initialize with some movies for demo
  const [watchlist, setWatchlist] = useState<Movie[]>(movies.slice(0, 8));
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleRemove = (id: number) => {
    setWatchlist(watchlist.filter(movie => movie.id !== id));
  };

  return (
    <div className="min-h-screen bg-[#0f0f0f]">
      <Navbar onMenuClick={() => setIsMobileMenuOpen(true)} />
      <Sidebar />
      <MobileMenu isOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
      
      <main className="md:ml-64 pt-16 pb-20 md:pb-0 min-h-screen">
        <div className="p-4 md:p-8">
          <div className="mb-6 md:mb-8">
            <div className="flex items-center gap-2 md:gap-3 mb-2">
              <Bookmark className="w-6 h-6 md:w-8 md:h-8 text-[#e50914]" />
              <h1 className="text-2xl md:text-4xl font-bold text-white">My Watchlist</h1>
            </div>
            <p className="text-sm md:text-base text-gray-400">{watchlist.length} movies saved</p>
          </div>

          {watchlist.length === 0 ? (
            <div className="text-center py-12 md:py-20">
              <Bookmark className="w-16 h-16 md:w-20 md:h-20 text-gray-600 mx-auto mb-4" />
              <h3 className="text-xl md:text-2xl font-semibold text-white mb-2">Your watchlist is empty</h3>
              <p className="text-sm md:text-base text-gray-400">Start adding movies you want to watch later!</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
              {watchlist.map((movie) => (
                <MovieCard 
                  key={movie.id} 
                  movie={movie}
                  showRemove
                  onRemove={handleRemove}
                />
              ))}
            </div>
          )}
        </div>
      </main>
      
      <MobileNav />
    </div>
  );
}