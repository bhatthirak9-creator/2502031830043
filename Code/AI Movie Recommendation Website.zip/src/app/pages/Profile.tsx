import { Edit, Mail, Calendar } from 'lucide-react';
import { Navbar } from '../components/Navbar';
import { Sidebar } from '../components/Sidebar';
import { MobileNav } from '../components/MobileNav';
import { MobileMenu } from '../components/MobileMenu';
import { MovieCard } from '../components/MovieCard';
import { movies } from '../data/movies';
import { useState } from 'react';

export default function Profile() {
  const watchHistory = movies.slice(0, 6);
  const [username, setUsername] = useState('John Doe');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleSave = () => {
    // Handle save logic here
    alert(`Username saved: ${username}`);
  };

  return (
    <div className="min-h-screen bg-[#0f0f0f]">
      <Navbar onMenuClick={() => setIsMobileMenuOpen(true)} />
      <Sidebar />
      <MobileMenu isOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
      
      <main className="md:ml-64 pt-16 pb-20 md:pb-0 min-h-screen">
        <div className="p-4 md:p-8">
          {/* Profile Header */}
          <div className="bg-gradient-to-br from-white/5 to-white/[0.02] backdrop-blur-md border border-white/10 rounded-2xl p-4 md:p-8 mb-6 md:mb-8">
            <div className="flex flex-col md:flex-row items-start gap-4 md:gap-8">
              <div className="relative mx-auto md:mx-0">
                <img 
                  src="https://images.unsplash.com/photo-1771050889377-b68415885c64?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBwZXJzb24lMjBhdmF0YXJ8ZW58MXx8fHwxNzcxOTcwMTIwfDA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Profile"
                  className="w-24 h-24 md:w-32 md:h-32 rounded-full object-cover border-4 border-[#e50914]"
                />
              </div>
              
              <div className="flex-1 w-full">
                <div className="flex flex-col md:flex-row items-start justify-between mb-4 md:mb-6 gap-4">
                  <div className="flex-1 w-full">
                    <div className="mb-2">
                      <label htmlFor="username" className="block text-sm text-gray-400 mb-2">Username</label>
                      <input
                        id="username"
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        placeholder="Enter your name"
                        className="w-full px-4 py-2.5 md:py-3 bg-white/5 border border-white/20 rounded-lg text-white text-xl md:text-2xl font-bold placeholder:text-gray-600 focus:outline-none focus:border-[#e50914] transition-colors"
                      />
                    </div>
                    <div className="flex flex-col gap-2 text-gray-400 text-sm md:text-base">
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4" />
                        <span>john.doe@email.com</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        <span>Member since January 2024</span>
                      </div>
                    </div>
                  </div>
                  
                  <button 
                    onClick={handleSave}
                    className="w-full md:w-auto flex items-center justify-center gap-2 px-6 py-3 bg-[#e50914] hover:bg-[#ff0a16] text-white rounded-lg font-semibold transition-all"
                  >
                    <Edit className="w-4 h-4" />
                    Save
                  </button>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-3 md:gap-6">
                  <div className="p-3 md:p-4 bg-white/5 rounded-lg border border-white/10">
                    <p className="text-gray-400 text-xs md:text-sm mb-1">Movies Watched</p>
                    <p className="text-2xl md:text-3xl font-bold text-white">127</p>
                  </div>
                  <div className="p-3 md:p-4 bg-white/5 rounded-lg border border-white/10">
                    <p className="text-gray-400 text-xs md:text-sm mb-1">Watchlist</p>
                    <p className="text-2xl md:text-3xl font-bold text-white">23</p>
                  </div>
                  <div className="p-3 md:p-4 bg-white/5 rounded-lg border border-white/10">
                    <p className="text-gray-400 text-xs md:text-sm mb-1">Favorite Genre</p>
                    <p className="text-lg md:text-xl font-bold text-white">Action</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Watch History */}
          <section className="mb-8 md:mb-12">
            <h2 className="text-xl md:text-2xl font-bold text-white mb-4 md:mb-6">Recently Watched</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-6">
              {watchHistory.map((movie) => (
                <MovieCard key={movie.id} movie={movie} />
              ))}
            </div>
          </section>

          {/* Preferences */}
          <section>
            <h2 className="text-xl md:text-2xl font-bold text-white mb-4 md:mb-6">Preferences</h2>
            <div className="bg-gradient-to-br from-white/5 to-white/[0.02] backdrop-blur-md border border-white/10 rounded-2xl p-4 md:p-6 space-y-3 md:space-y-4">
              <div className="flex items-center justify-between p-3 md:p-4 hover:bg-white/5 rounded-lg transition-colors cursor-pointer">
                <div>
                  <h3 className="text-white font-semibold mb-1 text-sm md:text-base">Email Notifications</h3>
                  <p className="text-xs md:text-sm text-gray-400">Receive updates about new releases</p>
                </div>
                <input type="checkbox" defaultChecked className="w-5 h-5 rounded border-white/10 bg-white/5 text-[#e50914] focus:ring-[#e50914]" />
              </div>
              
              <div className="flex items-center justify-between p-3 md:p-4 hover:bg-white/5 rounded-lg transition-colors cursor-pointer">
                <div>
                  <h3 className="text-white font-semibold mb-1 text-sm md:text-base">AI Recommendations</h3>
                  <p className="text-xs md:text-sm text-gray-400">Get personalized movie suggestions</p>
                </div>
                <input type="checkbox" defaultChecked className="w-5 h-5 rounded border-white/10 bg-white/5 text-[#e50914] focus:ring-[#e50914]" />
              </div>
              
              <div className="flex items-center justify-between p-3 md:p-4 hover:bg-white/5 rounded-lg transition-colors cursor-pointer">
                <div>
                  <h3 className="text-white font-semibold mb-1 text-sm md:text-base">Auto-play Trailers</h3>
                  <p className="text-xs md:text-sm text-gray-400">Automatically play movie trailers</p>
                </div>
                <input type="checkbox" className="w-5 h-5 rounded border-white/10 bg-white/5 text-[#e50914] focus:ring-[#e50914]" />
              </div>
            </div>
          </section>
        </div>
      </main>
      
      <MobileNav />
    </div>
  );
}