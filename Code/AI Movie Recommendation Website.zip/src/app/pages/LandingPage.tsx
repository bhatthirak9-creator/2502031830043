import { ChevronRight, Play } from 'lucide-react';
import { Link } from 'react-router';
import { Footer } from '../components/Footer';
import { trendingMovies } from '../data/movies';
import { MovieCard } from '../components/MovieCard';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-[#0f0f0f]">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1757186202331-e72fee53815f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaW5lbWElMjB0aGVhdGVyJTIwZGFya3xlbnwxfHx8fDE3NzE5MzIyNDV8MA&ixlib=rb-4.1.0&q=80&w=1080')`
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-[#0f0f0f] via-[#0f0f0f]/80 to-transparent" />
        </div>
        
        <div className="relative z-10 text-center max-w-4xl px-8">
          <h1 className="text-6xl md:text-7xl font-bold text-white mb-6">
            Find Your Next Favorite Movie with AI
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-12">
            Smart recommendations based on your mood & taste
          </p>
          <Link
            to="/login"
            className="inline-flex items-center gap-2 px-8 py-4 bg-[#e50914] hover:bg-[#ff0a16] text-white rounded-full transition-all transform hover:scale-105 shadow-lg shadow-[#e50914]/30"
          >
            <span className="text-lg font-semibold">Get Started</span>
            <ChevronRight className="w-5 h-5" />
          </Link>
        </div>
      </section>

      {/* Trending Movies Section */}
      <section className="max-w-[1440px] mx-auto px-8 py-20">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold text-white">Trending Now</h2>
          <Link to="/dashboard" className="text-[#e50914] hover:text-[#ff0a16] flex items-center gap-2 transition-colors">
            View All
            <ChevronRight className="w-5 h-5" />
          </Link>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {trendingMovies.map((movie) => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </div>
      </section>

      {/* Features Section */}
      <section className="max-w-[1440px] mx-auto px-8 py-20">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="p-8 rounded-2xl bg-gradient-to-br from-white/5 to-white/[0.02] backdrop-blur-md border border-white/10">
            <div className="w-14 h-14 rounded-full bg-[#e50914]/20 flex items-center justify-center mb-6">
              <Play className="w-7 h-7 text-[#e50914]" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-3">AI Powered</h3>
            <p className="text-gray-400">Get personalized recommendations based on your preferences and mood</p>
          </div>
          
          <div className="p-8 rounded-2xl bg-gradient-to-br from-white/5 to-white/[0.02] backdrop-blur-md border border-white/10">
            <div className="w-14 h-14 rounded-full bg-[#e50914]/20 flex items-center justify-center mb-6">
              <svg className="w-7 h-7 text-[#e50914]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-white mb-3">Huge Library</h3>
            <p className="text-gray-400">Access thousands of movies across all genres and languages</p>
          </div>
          
          <div className="p-8 rounded-2xl bg-gradient-to-br from-white/5 to-white/[0.02] backdrop-blur-md border border-white/10">
            <div className="w-14 h-14 rounded-full bg-[#e50914]/20 flex items-center justify-center mb-6">
              <svg className="w-7 h-7 text-[#e50914]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-white mb-3">Smart Filters</h3>
            <p className="text-gray-400">Filter by genre, mood, language, and more for perfect matches</p>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
