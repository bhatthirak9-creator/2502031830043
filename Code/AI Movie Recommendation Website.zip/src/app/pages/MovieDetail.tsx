import { useParams } from 'react-router';
import { Star, Play, Plus, Clock } from 'lucide-react';
import { Navbar } from '../components/Navbar';
import { Sidebar } from '../components/Sidebar';
import { MobileNav } from '../components/MobileNav';
import { MobileMenu } from '../components/MobileMenu';
import { MovieCard } from '../components/MovieCard';
import { movies } from '../data/movies';
import { useState } from 'react';

export default function MovieDetail() {
  const { id } = useParams();
  const movie = movies.find(m => m.id === Number(id));
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  if (!movie) {
    return <div className="text-white">Movie not found</div>;
  }

  const similarMovies = movies
    .filter(m => m.genre === movie.genre && m.id !== movie.id)
    .slice(0, 4);

  return (
    <div className="min-h-screen bg-[#0f0f0f]">
      <Navbar onMenuClick={() => setIsMobileMenuOpen(true)} />
      <Sidebar />
      <MobileMenu isOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
      
      <main className="md:ml-64 pt-16 pb-20 md:pb-0 min-h-screen">
        <div className="p-4 md:p-8">
          <div className="grid lg:grid-cols-3 gap-6 md:gap-8 mb-8 md:mb-12">
            {/* Movie Poster */}
            <div className="lg:col-span-1">
              <div className="md:sticky md:top-24">
                <img 
                  src={movie.image} 
                  alt={movie.title}
                  className="w-full rounded-2xl shadow-2xl"
                />
              </div>
            </div>

            {/* Movie Info */}
            <div className="lg:col-span-2">
              <h1 className="text-3xl md:text-5xl font-bold text-white mb-3 md:mb-4">{movie.title}</h1>
              
              <div className="flex flex-wrap items-center gap-3 md:gap-6 mb-4 md:mb-6">
                <div className="flex items-center gap-2">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i}
                      className={`w-5 h-5 md:w-6 md:h-6 ${i < Math.floor(movie.rating) ? 'fill-[#e50914] text-[#e50914]' : 'text-gray-600'}`}
                    />
                  ))}
                  <span className="text-lg md:text-xl text-white ml-2">{movie.rating}</span>
                </div>
                <span className="text-sm md:text-base text-gray-400">{movie.year}</span>
                {movie.duration && (
                  <div className="flex items-center gap-2 text-gray-400 text-sm md:text-base">
                    <Clock className="w-4 h-4 md:w-5 md:h-5" />
                    <span>{movie.duration}</span>
                  </div>
                )}
              </div>

              <div className="flex flex-wrap gap-2 md:gap-3 mb-4 md:mb-6">
                <span className="px-3 md:px-4 py-1.5 md:py-2 bg-white/10 rounded-full text-xs md:text-sm text-white border border-white/20">
                  {movie.genre}
                </span>
                {movie.language && (
                  <span className="px-3 md:px-4 py-1.5 md:py-2 bg-white/10 rounded-full text-xs md:text-sm text-white border border-white/20">
                    {movie.language}
                  </span>
                )}
                {movie.mood && (
                  <span className="px-3 md:px-4 py-1.5 md:py-2 bg-white/10 rounded-full text-xs md:text-sm text-white border border-white/20">
                    {movie.mood}
                  </span>
                )}
              </div>

              {movie.director && (
                <div className="mb-4 md:mb-6">
                  <p className="text-sm md:text-base text-gray-400 mb-1">Director</p>
                  <p className="text-base md:text-lg text-white">{movie.director}</p>
                </div>
              )}

              <div className="mb-6 md:mb-8">
                <h2 className="text-lg md:text-xl font-semibold text-white mb-2 md:mb-3">Synopsis</h2>
                <p className="text-sm md:text-lg text-gray-300 leading-relaxed">{movie.description}</p>
              </div>

              <div className="flex flex-col md:flex-row gap-3 md:gap-4">
                <button className="flex items-center justify-center gap-2 px-6 md:px-8 py-3 md:py-4 bg-[#e50914] hover:bg-[#ff0a16] text-white rounded-lg font-semibold transition-all transform hover:scale-105 shadow-lg shadow-[#e50914]/30">
                  <Play className="w-5 h-5" />
                  Watch Trailer
                </button>
                <button className="flex items-center justify-center gap-2 px-6 md:px-8 py-3 md:py-4 bg-white/10 hover:bg-white/20 text-white rounded-lg font-semibold transition-all border border-white/20">
                  <Plus className="w-5 h-5" />
                  Add to Watchlist
                </button>
              </div>
            </div>
          </div>

          {/* Similar Movies */}
          {similarMovies.length > 0 && (
            <section>
              <h2 className="text-xl md:text-2xl font-bold text-white mb-4 md:mb-6">Similar Movies</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
                {similarMovies.map((movie) => (
                  <MovieCard key={movie.id} movie={movie} />
                ))}
              </div>
            </section>
          )}
        </div>
      </main>
      
      <MobileNav />
    </div>
  );
}