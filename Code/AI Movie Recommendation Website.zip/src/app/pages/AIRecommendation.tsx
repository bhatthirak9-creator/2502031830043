import { useState, FormEvent } from 'react';
import { Sparkles } from 'lucide-react';
import { Navbar } from '../components/Navbar';
import { Sidebar } from '../components/Sidebar';
import { MobileNav } from '../components/MobileNav';
import { MobileMenu } from '../components/MobileMenu';
import { MovieCard } from '../components/MovieCard';
import { movies, Movie } from '../data/movies';

export default function AIRecommendation() {
  const [selectedGenre, setSelectedGenre] = useState('');
  const [selectedMood, setSelectedMood] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('');
  const [recommendations, setRecommendations] = useState<Movie[]>([]);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const genres = ['Action', 'Romance', 'Drama', 'Thriller', 'Sci-Fi', 'Crime', 'Animation'];
  const moods = ['Happy', 'Romantic', 'Thriller', 'Action'];
  const languages = ['English', 'Korean', 'Spanish', 'French'];

  const handleRecommend = (e: FormEvent) => {
    e.preventDefault();
    
    let filtered = movies;
    
    if (selectedGenre) {
      filtered = filtered.filter(m => m.genre === selectedGenre);
    }
    
    if (selectedMood) {
      filtered = filtered.filter(m => m.mood === selectedMood);
    }
    
    if (selectedLanguage) {
      filtered = filtered.filter(m => m.language === selectedLanguage);
    }
    
    setRecommendations(filtered);
  };

  return (
    <div className="min-h-screen bg-[#0f0f0f]">
      <Navbar onMenuClick={() => setIsMobileMenuOpen(true)} />
      <Sidebar />
      <MobileMenu isOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
      
      <main className="md:ml-64 pt-16 pb-20 md:pb-0 min-h-screen">
        <div className="p-4 md:p-8">
          <div className="mb-6 md:mb-8">
            <div className="flex items-center gap-2 md:gap-3 mb-2">
              <Sparkles className="w-6 h-6 md:w-8 md:h-8 text-[#e50914]" />
              <h1 className="text-2xl md:text-4xl font-bold text-white">AI Recommendations</h1>
            </div>
            <p className="text-sm md:text-base text-gray-400">Let AI find the perfect movie for you</p>
          </div>

          {/* Filter Form */}
          <div className="bg-gradient-to-br from-white/5 to-white/[0.02] backdrop-blur-md border border-white/10 rounded-2xl p-4 md:p-8 mb-8 md:mb-12">
            <form onSubmit={handleRecommend} className="space-y-4 md:space-y-6">
              <div className="grid md:grid-cols-3 gap-4 md:gap-6">
                <div>
                  <label className="block text-sm text-gray-300 mb-2 md:mb-3">Select Genre</label>
                  <select
                    value={selectedGenre}
                    onChange={(e) => setSelectedGenre(e.target.value)}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:border-[#e50914] focus:ring-1 focus:ring-[#e50914] transition-all"
                  >
                    <option value="">All Genres</option>
                    {genres.map(genre => (
                      <option key={genre} value={genre}>{genre}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-300 mb-2 md:mb-3">Select Mood</label>
                  <select
                    value={selectedMood}
                    onChange={(e) => setSelectedMood(e.target.value)}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:border-[#e50914] focus:ring-1 focus:ring-[#e50914] transition-all"
                  >
                    <option value="">All Moods</option>
                    {moods.map(mood => (
                      <option key={mood} value={mood}>{mood}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-300 mb-2 md:mb-3">Select Language</label>
                  <select
                    value={selectedLanguage}
                    onChange={(e) => setSelectedLanguage(e.target.value)}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:border-[#e50914] focus:ring-1 focus:ring-[#e50914] transition-all"
                  >
                    <option value="">All Languages</option>
                    {languages.map(language => (
                      <option key={language} value={language}>{language}</option>
                    ))}
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 md:py-4 bg-[#e50914] hover:bg-[#ff0a16] text-white rounded-lg font-semibold transition-all transform hover:scale-[1.02] shadow-lg shadow-[#e50914]/30 flex items-center justify-center gap-2"
              >
                <Sparkles className="w-5 h-5" />
                Get AI Recommendations
              </button>
            </form>
          </div>

          {/* Results */}
          {recommendations.length > 0 && (
            <section>
              <h2 className="text-xl md:text-2xl font-bold text-white mb-4 md:mb-6">
                Recommended for You ({recommendations.length} movies)
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
                {recommendations.map((movie) => (
                  <MovieCard key={movie.id} movie={movie} />
                ))}
              </div>
            </section>
          )}

          {recommendations.length === 0 && selectedGenre && (
            <div className="text-center py-12">
              <p className="text-sm md:text-lg text-gray-400">No movies found matching your criteria. Try different filters!</p>
            </div>
          )}
        </div>
      </main>
      
      <MobileNav />
    </div>
  );
}