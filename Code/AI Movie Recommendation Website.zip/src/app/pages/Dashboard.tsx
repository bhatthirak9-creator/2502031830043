import { useState } from 'react';
import { Navbar } from '../components/Navbar';
import { Sidebar } from '../components/Sidebar';
import { MobileNav } from '../components/MobileNav';
import { MobileMenu } from '../components/MobileMenu';
import { MovieCard } from '../components/MovieCard';
import { movies, Movie } from '../data/movies';

export default function Dashboard() {
  const [watchlist, setWatchlist] = useState<Movie[]>([]);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleAddToWatchlist = (movie: Movie) => {
    if (!watchlist.find(m => m.id === movie.id)) {
      setWatchlist([...watchlist, movie]);
    }
  };

  return (
    <div className="min-h-screen bg-[#0f0f0f]">
      <Navbar onMenuClick={() => setIsMobileMenuOpen(true)} />
      <Sidebar />
      <MobileMenu isOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
      
      <main className="md:ml-64 pt-16 pb-20 md:pb-0 min-h-screen">
        <div className="p-4 md:p-8">
          <div className="mb-6 md:mb-8">
            <h1 className="text-2xl md:text-4xl font-bold text-white mb-2">Discover Movies</h1>
            <p className="text-sm md:text-base text-gray-400">Explore our collection of amazing films</p>
          </div>

          {/* Popular This Week */}
          <section className="mb-8 md:mb-12">
            <h2 className="text-xl md:text-2xl font-bold text-white mb-4 md:mb-6">Popular This Week</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
              {movies.slice(0, 10).map((movie) => (
                <MovieCard 
                  key={movie.id} 
                  movie={movie}
                  onAddToWatchlist={handleAddToWatchlist}
                />
              ))}
            </div>
          </section>

          {/* New Releases */}
          <section className="mb-8 md:mb-12">
            <h2 className="text-xl md:text-2xl font-bold text-white mb-4 md:mb-6">New Releases</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
              {movies.slice(10, 18).map((movie) => (
                <MovieCard 
                  key={movie.id} 
                  movie={movie}
                  onAddToWatchlist={handleAddToWatchlist}
                />
              ))}
            </div>
          </section>
        </div>
      </main>
      
      <MobileNav />
    </div>
  );
}