import { Mail, Phone, MapPin, Send } from 'lucide-react';
import { Link } from 'react-router';
import { Footer } from '../components/Footer';
import { FormEvent } from 'react';

export default function Contact() {
  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    alert('Message sent! We\'ll get back to you soon.');
  };

  return (
    <div className="min-h-screen bg-[#0f0f0f]">
      {/* Header */}
      <header className="border-b border-white/10 py-4 md:py-6">
        <div className="max-w-[1440px] mx-auto px-4 md:px-8">
          <Link to="/" className="text-[#e50914] text-xl md:text-2xl font-bold">CineAI</Link>
        </div>
      </header>

      <main className="max-w-[1440px] mx-auto px-4 md:px-8 py-8 md:py-16">
        {/* About Section */}
        <section className="mb-12 md:mb-20">
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-4 md:mb-6">About CineAI</h1>
          <div className="grid lg:grid-cols-2 gap-8 md:gap-12">
            <div>
              <p className="text-base md:text-lg text-gray-300 mb-4 md:mb-6 leading-relaxed">
                CineAI is an AI-powered movie recommendation platform designed to help you discover your next favorite film. 
                Using advanced algorithms and machine learning, we analyze your preferences, mood, and viewing history to 
                provide personalized movie suggestions.
              </p>
              <p className="text-base md:text-lg text-gray-300 mb-4 md:mb-6 leading-relaxed">
                Our mission is to make movie discovery effortless and enjoyable. Whether you're looking for action-packed 
                blockbusters, romantic comedies, or thought-provoking dramas, CineAI has something for everyone.
              </p>
              <div className="grid grid-cols-2 gap-4 md:gap-6 mt-6 md:mt-8">
                <div className="p-4 md:p-6 bg-white/5 rounded-xl border border-white/10">
                  <p className="text-3xl md:text-4xl font-bold text-[#e50914] mb-2">10K+</p>
                  <p className="text-sm md:text-base text-gray-400">Movies</p>
                </div>
                <div className="p-4 md:p-6 bg-white/5 rounded-xl border border-white/10">
                  <p className="text-3xl md:text-4xl font-bold text-[#e50914] mb-2">50K+</p>
                  <p className="text-sm md:text-base text-gray-400">Users</p>
                </div>
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-white/5 to-white/[0.02] backdrop-blur-md border border-white/10 rounded-2xl p-6 md:p-8">
              <h2 className="text-xl md:text-2xl font-bold text-white mb-4 md:mb-6">Why Choose CineAI?</h2>
              <ul className="space-y-3 md:space-y-4">
                <li className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-[#e50914] flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-white text-sm">✓</span>
                  </div>
                  <div>
                    <h3 className="text-white font-semibold mb-1 text-sm md:text-base">AI-Powered Recommendations</h3>
                    <p className="text-gray-400 text-xs md:text-sm">Smart algorithms that learn your taste</p>
                  </div>
                </li>
                <li className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-[#e50914] flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-white text-sm">✓</span>
                  </div>
                  <div>
                    <h3 className="text-white font-semibold mb-1 text-sm md:text-base">Extensive Library</h3>
                    <p className="text-gray-400 text-xs md:text-sm">Thousands of movies across all genres</p>
                  </div>
                </li>
                <li className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-[#e50914] flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-white text-sm">✓</span>
                  </div>
                  <div>
                    <h3 className="text-white font-semibold mb-1 text-sm md:text-base">Mood-Based Search</h3>
                    <p className="text-gray-400 text-xs md:text-sm">Find movies that match your current mood</p>
                  </div>
                </li>
                <li className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-[#e50914] flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-white text-sm">✓</span>
                  </div>
                  <div>
                    <h3 className="text-white font-semibold mb-1 text-sm md:text-base">User-Friendly Interface</h3>
                    <p className="text-gray-400 text-xs md:text-sm">Clean, modern design for seamless experience</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section>
          <h2 className="text-2xl md:text-4xl font-bold text-white mb-8 md:mb-12">Get in Touch</h2>
          <div className="grid lg:grid-cols-2 gap-8 md:gap-12">
            {/* Contact Form */}
            <div className="bg-gradient-to-br from-white/5 to-white/[0.02] backdrop-blur-md border border-white/10 rounded-2xl p-6 md:p-8">
              <h3 className="text-xl md:text-2xl font-bold text-white mb-4 md:mb-6">Send us a Message</h3>
              <form onSubmit={handleSubmit} className="space-y-4 md:space-y-6">
                <div>
                  <label className="block text-sm text-gray-300 mb-2">Name</label>
                  <input
                    type="text"
                    placeholder="Your name"
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-[#e50914] focus:ring-1 focus:ring-[#e50914] transition-all"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm text-gray-300 mb-2">Email</label>
                  <input
                    type="email"
                    placeholder="your@email.com"
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-[#e50914] focus:ring-1 focus:ring-[#e50914] transition-all"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm text-gray-300 mb-2">Subject</label>
                  <input
                    type="text"
                    placeholder="What's this about?"
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-[#e50914] focus:ring-1 focus:ring-[#e50914] transition-all"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm text-gray-300 mb-2">Message</label>
                  <textarea
                    rows={5}
                    placeholder="Tell us more..."
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-[#e50914] focus:ring-1 focus:ring-[#e50914] transition-all resize-none"
                    required
                  />
                </div>
                
                <button
                  type="submit"
                  className="w-full py-4 bg-[#e50914] hover:bg-[#ff0a16] text-white rounded-lg font-semibold transition-all transform hover:scale-[1.02] shadow-lg shadow-[#e50914]/30 flex items-center justify-center gap-2"
                >
                  <Send className="w-5 h-5" />
                  Send Message
                </button>
              </form>
            </div>

            {/* Contact Info */}
            <div className="space-y-6">
              <div className="bg-gradient-to-br from-white/5 to-white/[0.02] backdrop-blur-md border border-white/10 rounded-2xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-[#e50914]/20 flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-[#e50914]" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold mb-1">Email</h3>
                    <p className="text-gray-400">support@cineai.com</p>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-br from-white/5 to-white/[0.02] backdrop-blur-md border border-white/10 rounded-2xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-[#e50914]/20 flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-[#e50914]" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold mb-1">Phone</h3>
                    <p className="text-gray-400">+1 (555) 123-4567</p>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-br from-white/5 to-white/[0.02] backdrop-blur-md border border-white/10 rounded-2xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-[#e50914]/20 flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-[#e50914]" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold mb-1">Address</h3>
                    <p className="text-gray-400">123 Cinema Street<br />Los Angeles, CA 90028</p>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-br from-[#e50914]/10 to-[#e50914]/5 backdrop-blur-md border border-[#e50914]/20 rounded-2xl p-6">
                <h3 className="text-white font-semibold mb-3">Business Hours</h3>
                <div className="space-y-2 text-gray-300">
                  <p>Monday - Friday: 9:00 AM - 6:00 PM</p>
                  <p>Saturday: 10:00 AM - 4:00 PM</p>
                  <p>Sunday: Closed</p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}