import { Home, Search, Sparkles, Bookmark, User } from 'lucide-react';
import { Link, useLocation } from 'react-router';

export function MobileNav() {
  const location = useLocation();
  
  const navItems = [
    { icon: Home, label: 'Home', path: '/dashboard' },
    { icon: Search, label: 'Search', path: '/genres' },
    { icon: Sparkles, label: 'AI', path: '/ai-recommendation' },
    { icon: Bookmark, label: 'Watchlist', path: '/watchlist' },
    { icon: User, label: 'Profile', path: '/profile' },
  ];
  
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-[#0f0f0f]/95 backdrop-blur-md border-t border-white/10">
      <div className="flex items-center justify-around px-4 py-3">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-all ${
                isActive 
                  ? 'text-[#e50914]' 
                  : 'text-gray-400'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-xs font-medium">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
