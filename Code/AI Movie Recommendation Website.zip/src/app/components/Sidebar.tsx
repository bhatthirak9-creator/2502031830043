import { Home, Film, Bookmark, Sparkles, User } from 'lucide-react';
import { Link, useLocation } from 'react-router';

export function Sidebar() {
  const location = useLocation();
  
  const menuItems = [
    { icon: Home, label: 'Home', path: '/dashboard' },
    { icon: Film, label: 'Genres', path: '/genres' },
    { icon: Bookmark, label: 'Watchlist', path: '/watchlist' },
    { icon: Sparkles, label: 'AI Recommendation', path: '/ai-recommendation' },
    { icon: User, label: 'Profile', path: '/profile' },
  ];
  
  return (
    <aside className="hidden md:block fixed left-0 top-16 bottom-0 w-64 bg-[#141414] border-r border-white/10 pt-8">
      <nav className="space-y-2 px-4">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                isActive 
                  ? 'bg-[#e50914] text-white' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}