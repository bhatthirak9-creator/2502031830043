import { Home, Film, Bookmark, Sparkles, User, X, Mail } from 'lucide-react';
import { Link, useLocation } from 'react-router';

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export function MobileMenu({ isOpen, onClose }: MobileMenuProps) {
  const location = useLocation();
  
  const menuItems = [
    { icon: Home, label: 'Home', path: '/dashboard' },
    { icon: Film, label: 'Genres', path: '/genres' },
    { icon: Bookmark, label: 'Watchlist', path: '/watchlist' },
    { icon: Sparkles, label: 'AI Recommendation', path: '/ai-recommendation' },
    { icon: User, label: 'Profile', path: '/profile' },
    { icon: Mail, label: 'Contact', path: '/contact' },
  ];
  
  if (!isOpen) return null;
  
  return (
    <>
      {/* Backdrop */}
      <div 
        className="md:hidden fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
        onClick={onClose}
      />
      
      {/* Menu */}
      <div className="md:hidden fixed top-0 left-0 bottom-0 w-[280px] bg-[#141414] z-50 border-r border-white/10">
        <div className="p-4">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-xl font-bold text-white">Menu</h2>
            <button
              onClick={onClose}
              className="p-2 rounded-full bg-white/5 hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5 text-white" />
            </button>
          </div>
          
          <nav className="space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={onClose}
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                    isActive 
                      ? 'bg-[#e50914] text-white' 
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>
      </div>
    </>
  );
}
