import { Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-[#0f0f0f] border-t border-white/10 py-12">
      <div className="max-w-[1440px] mx-auto px-8">
        <div className="flex flex-col items-center gap-6">
          <div className="flex gap-6">
            <a href="#" className="p-3 rounded-full bg-white/5 hover:bg-[#e50914] transition-colors">
              <Facebook className="w-5 h-5 text-white" />
            </a>
            <a href="#" className="p-3 rounded-full bg-white/5 hover:bg-[#e50914] transition-colors">
              <Twitter className="w-5 h-5 text-white" />
            </a>
            <a href="#" className="p-3 rounded-full bg-white/5 hover:bg-[#e50914] transition-colors">
              <Instagram className="w-5 h-5 text-white" />
            </a>
            <a href="#" className="p-3 rounded-full bg-white/5 hover:bg-[#e50914] transition-colors">
              <Youtube className="w-5 h-5 text-white" />
            </a>
          </div>
          <div className="flex gap-8 text-sm text-gray-400">
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Help Center</a>
            <a href="/contact" className="hover:text-white transition-colors">Contact Us</a>
          </div>
          <p className="text-sm text-gray-500">© 2026 CineAI. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
