import { Star, Plus } from 'lucide-react';
import { Movie } from '../data/movies';
import { Link } from 'react-router';

interface MovieCardProps {
  movie: Movie;
  onAddToWatchlist?: (movie: Movie) => void;
  showRemove?: boolean;
  onRemove?: (id: number) => void;
}

export function MovieCard({ movie, onAddToWatchlist, showRemove, onRemove }: MovieCardProps) {
  return (
    <Link to={`/movie/${movie.id}`} className="group block">
      <div className="relative overflow-hidden rounded-lg bg-[#1a1a1a] backdrop-blur-md border border-white/10 transition-all duration-300 hover:scale-105 hover:border-[#e50914] hover:shadow-xl hover:shadow-[#e50914]/20">
        <div className="aspect-[2/3] overflow-hidden">
          <img 
            src={movie.image} 
            alt={movie.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
        </div>
        <div className="p-3 md:p-4">
          <h3 className="text-base md:text-lg font-semibold text-white mb-1 md:mb-2 line-clamp-1">{movie.title}</h3>
          <div className="flex items-center justify-between mb-1 md:mb-2">
            <div className="flex items-center gap-0.5 md:gap-1">
              {[...Array(5)].map((_, i) => (
                <Star 
                  key={i}
                  className={`w-3 h-3 md:w-4 md:h-4 ${i < Math.floor(movie.rating) ? 'fill-[#e50914] text-[#e50914]' : 'text-gray-600'}`}
                />
              ))}
              <span className="text-xs md:text-sm text-gray-400 ml-1">{movie.rating}</span>
            </div>
            <span className="text-xs text-gray-500">{movie.year}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs md:text-sm text-gray-400">{movie.genre}</span>
            {showRemove ? (
              <button
                onClick={(e) => {
                  e.preventDefault();
                  onRemove?.(movie.id);
                }}
                className="text-xs text-[#e50914] hover:text-[#ff0a16] transition-colors"
              >
                Remove
              </button>
            ) : (
              <button
                onClick={(e) => {
                  e.preventDefault();
                  onAddToWatchlist?.(movie);
                }}
                className="p-1.5 rounded-full bg-white/10 hover:bg-[#e50914] transition-colors"
              >
                <Plus className="w-3 h-3 md:w-4 md:h-4 text-white" />
              </button>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
}