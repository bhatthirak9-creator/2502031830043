import { Search, User, Film, Menu } from 'lucide-react';
import { Link } from 'react-router';

interface NavbarProps {
  onMenuClick?: () => void;
}

export function Navbar({ onMenuClick }: NavbarProps) {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0f0f0f]/95 backdrop-blur-md border-b border-white/10">
      <div className="max-w-[1440px] mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
        {/* Hamburger Menu - Mobile Only */}
        <button
          onClick={onMenuClick}
          className="md:hidden p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
        >
          <Menu className="w-6 h-6 text-white" />
        </button>
        
        <Link to="/dashboard" className="flex items-center gap-2 text-[#e50914]">
          <Film className="w-6 h-6 md:w-8 md:h-8" />
          <span className="text-xl md:text-2xl font-bold">CineAI</span>
        </Link>
        
        {/* Desktop Search Bar */}
        <div className="hidden md:flex flex-1 max-w-xl mx-8">
          <div className="relative w-full">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search movies..."
              className="w-full pl-12 pr-4 py-2.5 bg-white/5 border border-white/10 rounded-full text-white placeholder-gray-500 focus:outline-none focus:border-[#e50914] focus:ring-1 focus:ring-[#e50914] transition-all"
            />
          </div>
        </div>
        
        <Link to="/profile" className="p-2 rounded-full bg-white/5 hover:bg-[#e50914] transition-colors">
          <User className="w-5 h-5 md:w-6 md:h-6 text-white" />
        </Link>
      </div>
    </nav>
  );
}